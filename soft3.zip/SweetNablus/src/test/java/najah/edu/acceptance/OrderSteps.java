package najah.edu.acceptance;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import najah.edu.Order;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class OrderSteps {
    private Order order;
    private final ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();

    @Given("the order management system is initialized")
    public void theOrderManagementSystemIsInitialized() {
        order = new Order();
        System.setOut(new PrintStream(outputStreamCaptor)); // Capture the system output
    }

    @When("I view all orders")
    public void iViewAllOrders() {
        order.viewOrders();
    }

    @Then("all orders should be displayed without errors")
    public void allOrdersShouldBeDisplayedWithoutErrors() {
        String output = outputStreamCaptor.toString();
        assert !output.isEmpty() : "Expected orders to be displayed but found empty output.";
    }

    @Given("the product with ID {int} exists in the content file with sufficient quantity")
    public void theProductWithIDExistsInTheContentFileWithSufficientQuantity(Integer productId) {
        // Assume product exists for testing purposes
        assert order.isProductExisting();
    }

    @When("I add product with ID {int} and quantity {int} to the cart")
    public void iAddProductWithIDAndQuantityToTheCart(Integer productId, Integer quantity) {
        order.setProductId(productId);
        order.editProductQuantity(quantity);
    }

    @Then("the product should be added to the cart successfully")
    public void theProductShouldBeAddedToTheCartSuccessfully() {
        assert order.isProductExisting() : "Expected product to be added to the cart but it was not.";
    }

    @Given("the cart is not empty")
    public void theCartIsNotEmpty() {
        order.addProductToCart();
        assert order.canEditQuantity() : "Expected cart to not be empty.";
    }

    @When("I cancel the current order")
    public void iCancelTheCurrentOrder() {
        order.cancelOrder1();
    }

    @Then("the cart should be cleared and all orders should be cancelled")
    public void theCartShouldBeClearedAndAllOrdersShouldBeCancelled() {
        assert order.cancelOrder() : "Expected the cart to be cleared and orders to be cancelled but it wasn't.";
    }

    @Given("an order with ID {string} exists")
    public void anOrderWithIDExists(String orderId) {
        order.setOrderId(orderId);
        order.setIfOrderExist(true); // Assume order exists
    }

    @When("I update the order with new order date {string}, new delivery date {string}, and new status {string}")
    public void iUpdateTheOrderWithNewOrderDateNewDeliveryDateAndNewStatus(String orderDate, String deliveryDate, String status) {
        order.updateOrder(); // Call update order method
    }

    @Then("the order should be updated successfully")
    public void theOrderShouldBeUpdatedSuccessfully() {
        assert order.isIfOrderExist() : "Expected the order to be updated but it was not found.";
    }

    @When("I delete the order with ID {string}")
    public void iDeleteTheOrderWithID(String orderId) {
        order.setOrderId(orderId);
        order.deleteOrder();
    }

    @Then("the order should be deleted successfully")
    public void theOrderShouldBeDeletedSuccessfully() {
        assert !order.isIfOrderExist() : "Expected the order to be deleted but it still exists.";
    }
}
